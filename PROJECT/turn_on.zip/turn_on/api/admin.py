from django.contrib import admin
# from .models import Employee

# # Register your models here.
# @admin.register(Employee)
# class EmployeeAdmin(admin.ModelAdmin):
#     list_display = ['id','name','email','password','address']
#     list_filter=('password',)
#     list_per_page=3
#     search_fields=('id',)

