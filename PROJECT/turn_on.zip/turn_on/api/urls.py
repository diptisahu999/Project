from django.urls import path
from api import views

urlpatterns= [
    path('',views.EmployeeListView.as_view(),name='employeeListView'),
    path('api/employees/<int:pk>',views.EmployeeDetailView.as_view(),name='employeeDetailView'),
    path('ee',views.turn_on)
   
]

